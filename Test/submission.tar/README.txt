// README.txt
Student ID: z5128703 Name: JIAHONG ZHANG
Installation Guide
1. client.zip contains all the html file in templates folder.
2. server.zip contains one csv file, 9 python file and one requirements
3. The whole assignment construction should be:
  Assignment2 ----------templates --------- admin.html
                     |                |
                     ---config.py     ---- (other html file)
                     |
                     ---run.py
                     |
                     --- (other py file)
2. First please SET the URI and root directory in config.py
3. Run python file run.py
4. Go to localhost:5000/login/ by using browser
4. Follow the instruction
4. The USERNAME and PASSWORD are all 'admin'