Student ID: z5106719 Name: Xingyu Li
Installation Guide
- unzip client.zip, put js file into static/js and put testClient.html into templates of unzipped server dictionary
- install requirements package by 'pip3 install -r requirements.txt'
- run views.py, start testClient by http://localhost:5000/
